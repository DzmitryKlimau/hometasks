﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Log;

namespace Items
{
    class ItemManager : ILoggable
    {

        public virtual void Click(string button)
        {
            // some click logic
        }
        public virtual void SetText(string text, string element)
        {
            // text setting logic
        }
        public virtual void Log(string logMessage)
        {
            // logging logic
        }
    }
}
