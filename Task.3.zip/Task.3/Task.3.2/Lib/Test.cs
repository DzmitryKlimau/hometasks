﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Logic;
namespace Tests
{
    class Test
    {
        // @Before
        // UserManager userManager = new UserManager();


        // @Test
        // Assert.Equals(usermanager.SaveUserData("John", "99"), 'some expected page condition');


        // @After
        // userManager = null;
    }
}
