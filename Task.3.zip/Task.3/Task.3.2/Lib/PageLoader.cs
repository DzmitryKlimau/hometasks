﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pages
{
    public abstract class PageLoader
    {
        public abstract void LoadPage(string url);
    }
}
