﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Configs
{
    class XMLReader : IReadConfig
    {
        public string Read(string pathToXml)
        {
            // read data from pathToXml
            string result = "Some config read from XML";
            return result;
        }
    }
}
