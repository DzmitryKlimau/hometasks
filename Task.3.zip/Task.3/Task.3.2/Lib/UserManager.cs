﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Items;
using Pages;
using Lib;

namespace Logic
{
    class UserManager
    {
        public void SaveUserData(string Name, int Age) {
            PageLoaderDesc loader = new PageLoaderDesc();
            TextFieldManager tfManager = new TextFieldManager();
            loader.LoadPage("url");
            tfManager.SetText("username", "username textfield");
            tfManager.SetText("age", "age textfield");
            tfManager.Click("save button");

        }
    }
}
