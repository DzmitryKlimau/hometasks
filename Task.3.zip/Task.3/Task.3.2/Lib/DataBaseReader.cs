﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Configs
{
    class DataBaseReader : IReadConfig
    {
        public string Read(string databaseName)
        {
            // connect to databaseName
            // execute config via query
            string result = "Some config executed from database";
            return result;
        }
    }
}
