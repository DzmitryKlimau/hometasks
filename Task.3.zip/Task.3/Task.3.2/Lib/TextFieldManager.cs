﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Items
{
    class TextFieldManager : ItemManager
    {
        public override void Click(string button)
        {
            // some new click logic
        }
        public override void SetText(string text, string item)
        {
            // new text setting logic
        }

        public override void Log(string logMessage) {
            base.Log(logMessage);
            // some additional log logic
        }

        public override string ToString()
        {
            return "Overrided ToString method from TextFieldManager";
        }
    }
}
