﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Log
{
    class Logger : ILoggable
    {
        public void Log(string logMessage)
        {
            // some logging logic
        }
    }
}
