﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace Lib
{
    class WebDriverInitializer
    {

        public string InitWebDriver() // return type should be of type 'WebDriver'
        {
            string webDriverInstance = "";
            string browser = ConfigurationManager.AppSettings["browser"];
            switch (browser) {
                case "chrome":
                    webDriverInstance = "New Chrome driver "+Browsers.CHROME;
                    break;
                case "firefox":
                    webDriverInstance = "New Firefox driver "+Browsers.FIREFOX;
                    break;
                case "ie":
                    webDriverInstance = "New Internet Explorer driver " + Browsers.IE;
                    break;
            }
            return webDriverInstance;
        }

    }
}
