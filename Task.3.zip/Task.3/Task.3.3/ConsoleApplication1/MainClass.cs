﻿using System;
using System.Linq;
using App;
using System.Reflection;
using System.Resources;
using System.IO;
using System.Configuration;
namespace Main
{
    class MainClass
    {
        static void Main(string[] args)
        {
            LogManager logger = LogManager.GetInstance;
            Communicator communicator = Communicator.GetInstance;
            InputValidityChecker checker = InputValidityChecker.GetInstance;
            string result = "";
            string timeStamp = "";
            // show help
            communicator.ShowOperationsHelp();
            // get operation from console
            string operationType = ReadOperation();
            if (operationType.Equals("linear") || operationType.Equals("quadratic)"))
            {
                // get indeces
                communicator.ShowIndecesHelp();
                string indeces = ReadIndeces();
                //check if indeces suit operationType(2 for linear and 3 for quadratic equation)          
                if (!checker.IndecesCountSuitOperation(indeces, operationType))
                {
                    string[] parsedIndeces = indeces.Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
                    int indecesCount = indeces.Count();
                    timeStamp = DateTime.Now.ToString("yyyy.mm.dd hh:mm:ss");
                    string msg = indecesCount + " is not a suitable quantity of indeces for '" + operationType + "' operation";
                    logger.WriteLog(timeStamp + " " + msg);
                    communicator.ShowIndecesDontSuitOperationAlert(indeces, operationType);
                    ReadIndeces();
                }
                // execute operation
                EquationSolverRunner runner = new EquationSolverRunner();
                result = runner.ExecuteOperation(operationType, indeces);
                //write result to console
                Console.WriteLine(result);
                timeStamp = DateTime.Now.ToString("yyyy.mm.dd hh:mm:ss");
                logger.WriteLog(timeStamp + " " + result);
            }
            else if (operationType.Equals("matrixm"))
            {
                ResourceManager rm = new ResourceManager("Resource1", Assembly.GetExecutingAssembly());
                string pathToFile = ConfigurationManager.AppSettings["matrices"];
                string[] source = File.ReadAllLines(pathToFile);
                MatrixManager matrixManager = MatrixManager.GetInstance;
                string[,] matrix1;
                string[,] matrix2;
                matrixManager.ParseTextToMatrices(source, out matrix1, out matrix2);
                if (!matrixManager.MatricesAreMultipliable(matrix1, matrix2))
                {
                    communicator.ShowMatricesAreNotMultipliableAlert();
                }
                string[,] resultMatrix = matrixManager.MultiplyMatrices(matrix1, matrix2);
                int rowCount = resultMatrix.GetLength(0);
                int colCount = resultMatrix.GetLength(1);
                for (int i = 0; i < rowCount; i++) {
                    for (int j = 0; j < colCount; j++) {
                        Console.Write(string.Format("{0} ", "\t"+resultMatrix[i, j]));
                    }
                    Console.Write(Environment.NewLine + Environment.NewLine);
                }                 
            }

            Console.ReadLine();

        }

        private static string ReadOperation()
        {
            LogManager logger = LogManager.GetInstance;
            InputValidityChecker checker = InputValidityChecker.GetInstance;
            Communicator communicator = Communicator.GetInstance;
            string operationType = Console.ReadLine();
            if (!checker.OperationIsValid(operationType))
            {
                string timeStamp = DateTime.Now.ToString("yyyy.mm.dd hh:mm:ss");
                string msg = "Incorrect operation entered";
                logger.WriteLog(timeStamp + " " + msg);
                communicator.ShowInvalidOperationAlert(operationType);
                ReadOperation();
            }
            return operationType;
        }
        private static string ReadIndeces()
        {
            LogManager logger = LogManager.GetInstance;
            InputValidityChecker checker = InputValidityChecker.GetInstance;
            Communicator communicator = Communicator.GetInstance;
            string indeces = Console.ReadLine();
            if (!checker.IndecesAreValid(indeces))
            {
                string timeStamp = DateTime.Now.ToString("yyyy.mm.dd hh:mm:ss");
                string msg = "Incorrect indeces(not numbers) or indeces count entered";
                logger.WriteLog(timeStamp + " " + msg);
                communicator.ShowInvalidIndecesAlert();
                ReadIndeces();
            }
            return indeces;
        }
    }
}
