﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    class Communicator
    {
        private static Communicator instance = null;
        private Communicator() { }
        public static Communicator GetInstance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Communicator();
                }
                return instance;
            }
        }
        public void ShowOperationsHelp()
        {
            Console.WriteLine("Please, choose operation.");
            Console.WriteLine("\tOperation:\t\t|Keyword:");
            Console.WriteLine("\t---------------------------------");
            Console.WriteLine("\tLinear equation\t\t|linear");
            Console.WriteLine("\tQuadratic equation\t|quadratic");
            Console.WriteLine("\tMatrix multiplication\t|matrixm");
        }

       

        public void ShowInvalidOperationAlert(string operationType)
        {
            Console.WriteLine("Operation '" + operationType + "' doesn't exist. Please choose from the list below: ");
            ShowOperationsHelp();
        }
        public void ShowIndecesHelp()
        {
            Console.WriteLine("Pleace input indeces");
            Console.WriteLine("For linear equation input 2 indeces. For quadratic equation - 3 indeces");
            Console.WriteLine("Indeces must contain only numbers. Indeces must be separated with a space");
        }
        public void ShowInvalidIndecesAlert()
        {
            Console.WriteLine("Invalid indeces count");
            ShowIndecesHelp();
        }
        public void ShowIndecesDontSuitOperationAlert(string indeces, string operationType)
        {
            string[] parsedIndeces = indeces.Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
            int indecesCount = parsedIndeces.Count();
            Console.WriteLine(indecesCount + " is not a suitable quantity of indeces for '" + operationType + "' operation.");
            ShowIndecesHelp();
        }

        public void ShowMatricesAreNotMultipliableAlert()
        {
            Console.WriteLine("Matrices are not multipliable");
            Console.WriteLine("1st matrix column count must equal second matrix row count");
        }
    }
}
