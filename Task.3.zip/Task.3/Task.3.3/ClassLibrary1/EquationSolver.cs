﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    public class EquationSolver
    {
        public void SolveLinear(double a, double b, out string x)
        {

            if ((a == 0) & (b == 0))
            {
                x = "any";
            }
            else if (a == 0)
            {
                x = "absent";
            }
            else
            {
                x = (-b / a).ToString("#.##");
            }
        }
        public void SolveQuadratic(double a, double b, double c, out string x1, out string x2)

        {
            //x1 and x2 are made string in order to be able to put "absent" 
            //value to it when equation has no roots or only one root
            x1 = "";
            x2 = "";
            string absent = "absent";

            if (a == 0 & b == 0 & c == 0)
            {
                x1 = "any";
                x2 = "any";
            }

            else if (a == 0 & b == 0)
            {
                x1 = absent;
                x2 = absent;
            }
            else if (a == 0 & c == 0)
            {
                x1 = "0";
                x2 = absent;
            }
            else if (b == 0 & c == 0)
            {
                x1 = "0";
                x2 = absent;
            }
            else if (a == 0)
            {
                x1 = (-c / b).ToString("#.##");
                x2 = absent;
            }
            else if (b == 0)
            {
                if (c < 0)
                {
                    x1 = absent;
                    x2 = absent;
                }
                else
                {
                    x1 = (-Math.Sqrt(-c / a)).ToString("#.##");
                    x2 = (Math.Sqrt(-c / a)).ToString("#.##");
                }
            }
            else if (c == 0)
            {
                x1 = "0";
                x2 = (-b / a).ToString("#.##");
            }


            // finally if none of the indeces equals 0 we can use standart
            // way to solve quadratic equation
            else
            {
                double disc = b * b - 4 * a * c;
                x1 = ((-b + Math.Sqrt(disc)) / (2 * a)).ToString("#.##");
                x2 = ((-b - Math.Sqrt(disc)) / (2 * a)).ToString("#.##");
            }

        }
    }
}