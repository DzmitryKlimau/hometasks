﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    public class MatrixManager
    {
        private static MatrixManager instance = null;
        private MatrixManager() { }
        public static MatrixManager GetInstance
        {
            get
            {
                if (instance == null)
                {
                    instance = new MatrixManager();
                }
                return instance;
            }
        }
         public void ParseTextToMatrices(string[] source, out string[,] matrix1, out string[,] matrix2)
        {            
            int i;
            //search for delimeter line index
            for (i = 0; i < source.Count(); i++)
            {
                if (source[i] == "123")
                {
                    break;
                }
            }
            // 1st matrix = subarray of sourceArray from 0 to delimeter line exclusively
            string[] unparsedMatrix1 = new string[i];
            Array.Copy(source, 0, unparsedMatrix1, 0, i);
            // 2nd matrix = subarray of sourceArray from delimeter line exclusively and to the end of SourceArray
            int matrix2Count = source.Count() - unparsedMatrix1.Count() - 1;// '1' here stands for delimeter line
            string[] unparsedMatrix2 = new string[matrix2Count];
            Array.Copy(source, i + 1, unparsedMatrix2, 0, matrix2Count);
            matrix1 = MakeTwoDimMatrix(unparsedMatrix1);
            matrix2 = MakeTwoDimMatrix(unparsedMatrix2);
        }
        private string[,] MakeTwoDimMatrix(string[] source)
        {
            // assume that sourceMatrix is multiDimensional(but not jagged) 
            // so all rows are same length, 
            int rows;
            int cols;
            CountDimensions(source, out rows, out cols);
            string[,] matrix = new string[rows, cols];
            for (int i = 0; i < rows; i++)
            {
                string[] parsedRow = source[i].Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = parsedRow[j];
                }
            }
            return matrix;
        }
        private void CountDimensions(string[] source, out int rows, out int cols)
        {
            rows = source.Count();
            string[] parsedRow = source[0].Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
            cols = parsedRow.Count();
        }
        public bool MatricesAreMultipliable(string[,] matrix1, string[,] matrix2)
        {
            int matrix1ColsCount = matrix1.GetLength(1);
            int matrix2RowsCount = matrix1.GetLength(0);
            if (matrix1ColsCount!=matrix2RowsCount)
            {
                return false;
            }
            return true;
        }
        public string[,] MultiplyMatrices(string[,] matrix1, string[,] matrix2)
        {
            int resultRows = matrix1.GetLength(0);
            int resultCols = matrix2.GetLength(1);
            string[,] result = new string[resultRows, resultCols];
            for (int i = 0; i < result.GetLength(0); i++) {
                for (int j = 0; j < result.GetLength(1); j++) {
                    result[i, j] = "0";
                    for (int k = 0; k < matrix1.GetLength(1); k++) {
                        result[i, j] = (double.Parse(result[i, j]) + double.Parse(matrix1[i, k]) * double.Parse(matrix2[k, j])).ToString("#.##");
                    }
                }
            }

            return result;
        }
        
    }


}
