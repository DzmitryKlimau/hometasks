﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    public class EquationSolverRunner
    {
        private EquationSolver solver = new EquationSolver();
        public string ExecuteOperation(string operation, string indeces)
        {
            string[] parsedIndeces = indeces.Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
            string result = "";
            string x1 = "";
            string x2 = "";
            if (operation.Equals("linear"))
            {
                double a = Double.Parse(parsedIndeces[0]);
                double b = Double.Parse(parsedIndeces[1]);
                solver.SolveLinear(a, b, out x1);
                result = "x = " + x1;
            }
            else if (operation.Equals("quadratic"))
            {
                double a = Double.Parse(parsedIndeces[0]);
                double b = Double.Parse(parsedIndeces[1]);
                double c = Double.Parse(parsedIndeces[2]);
                solver.SolveQuadratic(a, b, c, out x1, out x2);
                result = "x1 = " + x1 + ", x2 = " + x2;
            }
           
            return result;
        }
    }
}
