﻿using System;
using System.IO;
namespace App
{
    public class LogManager
    {
        private string pathToFile;
        private static LogManager instance = null;
        
        // 'log.txt' is created in current project directory(ConsoleApplication1)
        private LogManager() {
            string currDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;
            pathToFile = Path.Combine(currDirectory, "log.txt");
            
        }
        public static LogManager GetInstance
        {
            get
            {
                if (instance == null)
                {
                    instance = new LogManager();
                }
                return instance;
            }
        }


        public void WriteLog(string logRecord) {
            File.AppendAllText(pathToFile, logRecord+Environment.NewLine);
        }

    }
}
