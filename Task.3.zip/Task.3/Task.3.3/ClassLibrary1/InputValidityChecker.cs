﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App
{
    public class InputValidityChecker
    {
        private static InputValidityChecker instance = null;
        private InputValidityChecker() { }
        public static InputValidityChecker GetInstance
        {
            get{
                if (instance == null) {
                    instance = new InputValidityChecker();
                }
                return instance;
            }
           
        }
        public bool IndecesAreValid(string indeces)
        {
            string[] parsedIndeces = indeces.Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
            // check if we have either 2(for linear equations) or 3(for quadratic equations) indeces
            if (parsedIndeces.Count() != 2 &
                parsedIndeces.Count() != 3
                )
            {
                return false;
            }
            // check if all indeces are numbers
            for (int i = 0; i < parsedIndeces.Count(); i++) {
                double n;
                bool isNumeric = double.TryParse(parsedIndeces[i], out n);
                if (!isNumeric) {
                    return false;
                }
            }
            return true;
        }
        public bool IndecesCountSuitOperation(string indeces, string operationType)
        {
            string[] parsedIndeces = indeces.Split(new char[0], StringSplitOptions.RemoveEmptyEntries);
            if (operationType.Equals("linear")) {
                if (parsedIndeces.Count() != 2) {
                    return false;
                }
            }

            else if (operationType.Equals("quadratic"))
            {
                if (parsedIndeces.Count() != 3)
                {
                    return false;
                }
            }
            
           
            return true;
        }        
        public bool OperationIsValid(string operationType)
        {
            if (operationType.Equals("quadratic") ||
                operationType.Equals("linear") ||
                operationType.Equals("matrixm")
                )
            {
                return true;
            }
            return false;
        }
    }
}
