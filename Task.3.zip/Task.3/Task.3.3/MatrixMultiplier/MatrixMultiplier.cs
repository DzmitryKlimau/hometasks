﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using App;

namespace MatrixMultiplier
{
    class MatrixMultiplier
    {
        static void Main(string[] args)
        {/*
            string[] source = File.ReadAllLines("d:/res/matrixExample.txt");
            MatrixManager mm = MatrixManager.GetInstance;
            int rows;
            int cols;
           mm.CountDimensions(source, out rows, out cols);
            string[,] matrix = mm.MakeTwoDimMatrix(source);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    Console.WriteLine(matrix[i, j]);
                }
            }
            Console.ReadLine();*/
        }


        }
}
