﻿using System;
using System.IO;
namespace Task._3._1
{
    class Program
    {
        static void Main(string[] args)
        {
            //get apth from console
            Console.WriteLine("Please, enter destination folder name.");
            string destinationFolder = Console.ReadLine();
            // create directory from path and create outpu file
            if (!Directory.Exists(destinationFolder)) {
                Directory.CreateDirectory(destinationFolder);
            }
            string outPath = Path.Combine(destinationFolder, "out.txt");
            if (!File.Exists(outPath))
            {
                File.Create(outPath);
            }
           
            // get sourceFile path from resource file. Change to desired path in 'Resource1.resx'
            
            string sourceFile = Resource.sourceFile;// this works fine but when I try...

            /*ResourceManager rm = new ResourceManager("items", Assembly.GetExecutingAssembly());
               string sourceFile = rm.GetString("sourceFile");
             */
             // ...for some reason it crashes with MissingManifestResourceException

            // read text from sourceFile
            string text = File.ReadAllText(sourceFile);
            // write text to output file
            File.WriteAllText(outPath, text);
        }
    }
}
