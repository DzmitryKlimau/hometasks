﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lib;
namespace Tests
{
    [TestClass]
    public class TestLib
    {
        Functions funcs = new Functions();
        [TestMethod]
        public void TestSum()
        {
            Assert.AreEqual(5, funcs.Sum(2,3));
        }
        [TestMethod]
        public void TestSubstriction()
        {
            Assert.AreEqual(3, funcs.Substract(5, 2));
        }
        [TestMethod]
        public void TestMultiplication()
        {
            Assert.AreEqual(6, funcs.Multiply(2, 3));
        }
        [TestMethod]
        public void TestDivision()
        {
            Assert.AreEqual(2, funcs.Divide(8, 4));
        }
        
    }
}
