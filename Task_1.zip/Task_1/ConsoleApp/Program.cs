﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lib;
using System.Configuration;
using System.Resources;
using System.Reflection;
using ConsoleApp.Properties;

namespace ConsoleApp
{
    class ConsoleApp
    {
        static void Main(string[] args)
        {
            string dataSource = ConfigurationManager.AppSettings["dataSource"];
            string methodSource = ConfigurationManager.AppSettings["methodSource"];

          
            //check data source
            int firstNumber = 0;
            int secondNumber = 0;
            if (dataSource.Equals("console"))
            {
                Console.WriteLine("Manual input is used");
                Console.WriteLine("Input first number");
                firstNumber = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Input second number");
                secondNumber = Int32.Parse(Console.ReadLine());
            }
            else if (dataSource.Equals("resourceFile")) {
                Console.WriteLine("Resource file is used");
                firstNumber = Int32.Parse(Resources.ResourceManager.GetString("firstNumber"));
                secondNumber = Int32.Parse(Resources.ResourceManager.GetString("secondNumber"));
            }

            // check method source
            if (methodSource.Equals("console"))
            {
                Console.WriteLine("Sum method from console");
                int sumConsole = firstNumber + secondNumber;
                Console.WriteLine(sumConsole);
                Console.ReadLine();
            }
            else if (methodSource.Equals("lib"))
            {
                Console.WriteLine("Methods from library");
                Functions func = new Functions();
                int sumLib = func.Sum(firstNumber, secondNumber);
                int substrLib = func.Substract(firstNumber, secondNumber);
                int multLib = func.Multiply(firstNumber, secondNumber);
                double divLib = func.Divide(firstNumber, secondNumber);
                Console.WriteLine("Sum " + sumLib);
                Console.WriteLine("Substraction " + substrLib);
                Console.WriteLine("Multiplication " + multLib);
                Console.WriteLine("Division " + divLib);
                Console.ReadLine();
            }
        }
    }
}
