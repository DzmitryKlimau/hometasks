﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib
{
    public class Functions
    {
        public int Sum(int a, int b) {
            return a + b;
        }
        public int Substract(int a, int b) {
            return a - b;
        }
        public int Multiply(int a, int b) {
            return a * b;
        }
        public double Divide(int a, int b) {
            return a / b;
        }

    }
}
