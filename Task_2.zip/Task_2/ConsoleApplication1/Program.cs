﻿using System.IO;
namespace Task_2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"d:\res\Text.txt";
            // read text from file
            string text = File.ReadAllText(path);
            
            // upper case letters to lower case
            text = text.ToLower();

            // each sentence from new line and add timestamp to all sentences
            string dateTimeFormat = "yyyy-MM-dd HH:mm:ss:fff";
            string currentTime = System.DateTime.Now.ToString(dateTimeFormat);
            text = currentTime+" " +text;// to the first sentence
            text = text.Replace(". ", ".\n"+currentTime+" ");// to all another sentences

            System.Console.WriteLine(text);
            System.Console.ReadKey();
        }
    }
}
