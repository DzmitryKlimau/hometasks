﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Collections;
namespace Task_2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please, enter text.");
            Console.WriteLine("Enter 'exit' to stop");

            //read input
            string text = ReadFromConsole();
            // make wordlist(including numbers) from text
            List<string> commonList = MakeCommonList(text);

            // extract integers from wordlist
            List<int> intList = GetIntegersFromText(commonList);
            // remove integers from common list
            foreach (int element in intList)
            {
                commonList.Remove(element.ToString());
            }
            //make necessary operations(count elements, sort, calculate everage)
            int intCount = intList.Count;
            intList.Sort();
            double intAverage = intList.Average();
            //output result
            Console.WriteLine("Entered integers. Count = "+intCount+":");
            foreach (int num in intList) {
                Console.WriteLine("{0,10}", num);
            }
            Console.WriteLine("{0,10}", "Average: "+ intAverage);
            Console.WriteLine("\n");

            // extract doubles from wordlist
            List<double> doubleList = GetDoublesFromText(commonList);
            // remove doubles from common list
            foreach (double element in doubleList)
            {
                commonList.Remove(element.ToString());
            }
            // make necessary operations(count elements, round, sort, calculate everage)
            int doubleCount = doubleList.Count;
            for (int i = 0; i < doubleList.Count; i++) {
                doubleList[i] = Math.Round(doubleList.ElementAt(i), 2); ;
            }
            doubleList.Sort();
            double doubleAverage = Math.Round(doubleList.Average(), 2);
            //output result
            Console.WriteLine("Entered doubles.Count = " + doubleCount + ":");
            foreach (double num in doubleList)
            {
                Console.WriteLine("{0,10}", num);
            }
            Console.WriteLine("{0,10}", "Average: "+doubleAverage);
            Console.WriteLine("\n");
          
            // everything else except ints and doubles is assumed to be words
            List<string> wordList = commonList;
            wordList =  wordList.OrderBy(x => x.Length).ToList();
            // output result
            Console.WriteLine("Entered words:");
            wordList.ForEach(Console.WriteLine);
            Console.ReadLine();
        }

        private static List<string> GetWordsFromText(List<string> commonList, List<int> intList, List<double> doubleList)
        {

            foreach (int num in intList)
            {
                commonList.Remove(num.ToString());
            }
            foreach (double num in doubleList)
            {
                commonList.Remove(num.ToString());
            }
            return commonList;
        }

        public static string ReadFromConsole() {
            StringBuilder builder = new StringBuilder();
            string line;
            while ((line = Console.ReadLine()) != "exit")
            {
                builder.Append(line + " ");
            }
            return builder.ToString();
        }
        public static List<string> MakeCommonList(string text)
        {
            text = Regex.Replace(text, @"[.;\/:-_=+]", "");
            string[] words = Regex.Split(text, " ");
            List<string> wordList = words.ToList();
            return wordList;
        }
        public static List<int>  GetIntegersFromText(List<string> commonList) {
            List<int> intList = new List<int> ();
            foreach (string word in commonList)
            {
                int num;
                if (int.TryParse(word, out num))
                {
                    intList.Add(num);
                }
            }
            return intList;
        }
        public static List<double> GetDoublesFromText(List<string> commonList) {
            List<double> doubleList = new List<double>();
            foreach (string word in commonList)
            {
                double num;
                if (double.TryParse(word, out num))
                {
                    doubleList.Add(num);
                }
            }
            return doubleList;
        }
       

    }
}
