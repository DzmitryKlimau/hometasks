﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task._4._2
{
    class TestMathOperations
    {
        public static void Main()
        {
            int fib = 5;// change to desired
            int fac = 5; // change to desired
            for (int i = 0; i < fib; i++)
            {
                Console.WriteLine(MathOperations.Fibonacci(i));
            }
            Console.WriteLine();
            Console.WriteLine(MathOperations.Factorial(fac));

            Console.ReadLine();
        }
    }
}
