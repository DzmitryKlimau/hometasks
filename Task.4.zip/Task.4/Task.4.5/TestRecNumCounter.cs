﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task._4._5
{
    class TestRecNumCounter
    {
        static void Main(string[] args)
        {
        }
    }
}
