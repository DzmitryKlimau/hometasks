﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task._4._5
{
    class RecNumCounter
    {
        public double CountRecNumber(double bigSquare, double aSide, double bSide) {
            double smallSquare = aSide * bSide;
            double rectangleCount = bigSquare / smallSquare;
            return rectangleCount;
        }
    }
}
