﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task._4._3
{
    class TestCopyCounter
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Before creating: "+CopyCounter.GetCopiesNum());
            CopyCounter c1 = new CopyCounter();
            CopyCounter c2 = new CopyCounter();
            CopyCounter c3 = new CopyCounter();
            Console.WriteLine("After creating: "+CopyCounter.GetCopiesNum());
            Console.ReadLine();

        }
    }
}
