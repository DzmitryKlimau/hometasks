﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task._4._3
{
    class CopyCounter
    {
        private static int copiesNum = 0;

        public CopyCounter()
        {
            copiesNum++;
        }
        public static int GetCopiesNum()
        {
            return copiesNum;
        }
    }

}

