﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils
{
    class WebDriverInitializer
    {
        public string InitDriver(string driverName)
        {
            string driver = "new Driver('" + driverName + "')";
            return driver;
        }
    }
}
