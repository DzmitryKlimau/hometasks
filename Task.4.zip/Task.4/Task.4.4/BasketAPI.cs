﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils;
using System.Configuration;
namespace Api
{
    public class BasketAPI
    {
        private WebDriverInitializer wdInitzer = new WebDriverInitializer();
        private string browser = ConfigurationManager.AppSettings["browser"];

        public void AddProduct(string productName)
        {
            string webDriver = wdInitzer.InitDriver(browser); 
            // load startPage           
            // find product by productName
            // find 'Add to basket' button near the product
            // click found button
        }
        public void DeleteProductName(string productName)
        {
            string webDriver = wdInitzer.InitDriver(browser);
            // load startPage   
            // find basket icon and click it
            // find product by name in the basket
            // click 'Delete' button near the product

        }
        public void CountTotal()
        {
            string webDriver = wdInitzer.InitDriver(browser);
            // load startPage   
            // go to basket page
            // find 'Total' field
            // get value from 'Total' field
        }
    }
}

