﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task._4._1
{
    public class Point
    {
        private int x;
        private int y;
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public override string ToString()
        {
            return String.Format("X:{0}, Y:{1}", x, y);
            //or
            // return "x = " + x + ", y = " + y;
        }

        public override bool Equals(Object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (this == obj)
            {
                return true;
            }
            Point point = obj as Point;
            if ((System.Object)point == null)
            {
                return false;
            }
            return (x == point.x) && (y == point.y);
        }
    }
}
